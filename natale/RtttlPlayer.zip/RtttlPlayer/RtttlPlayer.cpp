/*
  RtttlPlayer - an Arduino RTTTL Player library - v1.0
  Copyright (c) 2017 Jwebs
  Licenza Creative Commons BY-NC-SA 3.0 IT (https://creativecommons.org/licenses/by-nc-sa/3.0/it/deed.it)
*/
#include "Arduino.h"
#include "RtttlPlayer.h"

RtttlPlayer::RtttlPlayer(int pin){
  pinMode(pin, OUTPUT);
  _pin = pin;
  _isPlaying = false;
}

void RtttlPlayer::play(char *song){
  _song = song;
  getInfo();
  noTone(_pin);
  if(parseNote()){
    _timestamp = millis();
    _isPlaying = true;
    tone(_pin, _frequency, _duration);
  }else{
    _isPlaying = false;
  }
}

void RtttlPlayer::getInfo(){
  _cursor = 0;
  
  _songTitle = "";
  while(_song[_cursor] != ':' && _song[_cursor] != '\0'){
    _songTitle += _song[_cursor++];
  }
  if(_song[_cursor] == ':'){
    ++_cursor;
  }

  _defaultDuration = 0;
  if(_song[_cursor] == 'd'){
    _cursor += 2;
    while(isDigit(_song[_cursor])){
      _defaultDuration = (_defaultDuration * 10) + (_song[_cursor++]-'0');
    }
    while(_song[_cursor] != ',' && _song[_cursor] != '\0'){
      ++_cursor;
    }
    if(_song[_cursor] == ','){
      ++_cursor;
    }
  }
  
  _defaultOctave = 0;
  if(_song[_cursor] == 'o'){
    _cursor += 2;
    while(isDigit(_song[_cursor])){
      _defaultOctave = (_defaultOctave * 10) + (_song[_cursor++]-'0');
    }
    while(_song[_cursor] != ',' && _song[_cursor] != '\0'){
      ++_cursor;
    }
    if(_song[_cursor] == ','){
      ++_cursor;
    }
  }
  
  int bpm = 0;
  _noteDuration = 0;
  if(_song[_cursor] == 'b'){
    _cursor += 2;
    while(isDigit(_song[_cursor])){
      bpm = (bpm * 10) + (_song[_cursor++]-'0');
    }
    while(_song[_cursor] != ':' && _song[_cursor] != '\0'){
      ++_cursor;
    }
    if(_song[_cursor] == ':'){
      ++_cursor;
    }
  }
  if(bpm > 0){
    _noteDuration = 60000L/bpm * 4;
  }
  _noteCursor = _cursor;
}

bool RtttlPlayer::parseNote(){
  if(_song[_cursor] != '\0'){
    bool noteFound = false;
    _duration = 0;
    _octave = 0;
    int note = 0;
    while(_song[_cursor] != ',' && _song[_cursor] != '\0'){
      if(isDigit(_song[_cursor])){
        if(!noteFound){
          _duration = (_duration * 10) + (_song[_cursor]-'0');
        }else{
          _octave = _song[_cursor]-'0';
        }
      }else{
        noteFound = true;
        switch(_song[_cursor]){
          case 'c': note = 1; break;
          case 'd': note = 3; break;
          case 'e': note = 5; break;
          case 'f': note = 6; break;
          case 'g': note = 8; break;
          case 'a': note = 10; break;
          case 'b': note = 12;  break;
          case '#': ++note;  break;
          case '.': _duration += _duration / 2;  break;
        }
      }
      ++_cursor;
    }
    if(_song[_cursor] == ','){
      ++_cursor;
    }
    
    if(_duration > 0){
      _duration = _noteDuration / _duration;
    }else{
      _duration = _noteDuration / _defaultDuration;
    }
    
    if(_octave == 0){
      _octave = _defaultOctave;
    }
    
    int notes[49] = {
      0, NOTE_C4, NOTE_CS4, NOTE_D4, NOTE_DS4, NOTE_E4, NOTE_F4, NOTE_FS4, NOTE_G4, NOTE_GS4, 
      NOTE_A4, NOTE_AS4, NOTE_B4, NOTE_C5, NOTE_CS5, NOTE_D5, NOTE_DS5, NOTE_E5, NOTE_F5, NOTE_FS5, 
      NOTE_G5, NOTE_GS5, NOTE_A5, NOTE_AS5, NOTE_B5, NOTE_C6, NOTE_CS6, NOTE_D6, NOTE_DS6, NOTE_E6, 
      NOTE_F6, NOTE_FS6, NOTE_G6, NOTE_GS6, NOTE_A6, NOTE_AS6, NOTE_B6, NOTE_C7, NOTE_CS7, NOTE_D7, 
      NOTE_DS7, NOTE_E7, NOTE_F7, NOTE_FS7, NOTE_G7, NOTE_GS7, NOTE_A7, NOTE_AS7, NOTE_B7
    };
    
    if(note){
      _frequency = notes[(_octave-4)*12+note];
    }else{
      _frequency = 0;
    }
    return true;
  }else{
  	return false;
  }
}

void RtttlPlayer::update(){
  if(_isPlaying && (millis()-_timestamp)>_duration+5){
    if(parseNote()){
      _timestamp = millis();
      tone(_pin, _frequency, _duration);
    }else{
      _isPlaying = false;
    }
  }
}

void RtttlPlayer::stop(){
  _isPlaying = false;
  _cursor = 0;
}

String RtttlPlayer::getSongTitle(){
  return _songTitle;
}

bool RtttlPlayer::isPlaying(){
  return _isPlaying;
}

